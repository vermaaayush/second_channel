<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the login page
    header("Location: login.php");
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
    require_once '../conn.php';

    // Define variables to store form data
    $currencyName = $_POST['name'];
    $buyPrice = $_POST['b_price'];
    $salePrice = $_POST['s_price'];
    $description = $_POST['description'];

    // Check if file is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Get file details
        $fileName = $_FILES['image']['name'];
        $fileTmpName = $_FILES['image']['tmp_name'];
        $fileType = $_FILES['image']['type'];
        $fileSize = $_FILES['image']['size'];

        // Define folder path to store uploaded files
        $uploadFolder = 'flag/';

        // Move uploaded file to folder
        $filePath = $uploadFolder . $fileName;
        if (move_uploaded_file($fileTmpName, $filePath)) {
            // File moved successfully, now insert data into database
            $sql = "INSERT INTO forex (name, image, b_price, s_price, description) 
                    VALUES ('$currencyName', '$filePath', $buyPrice, $salePrice, '$description')";
            if ($conn->query($sql) === TRUE) {
                // Redirect to dashboard after adding data to database
                header("Location: dashboard.php");
                exit;
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Error uploading file.";
        }
    } else {
        echo "File upload error.";
    }
}

require 'header.php';
?>




  <!-- ===============>> Blogs section start here <<================= -->
  <div class="blog padding-top padding-bottom section-bg-color">
    
  <section>
    <div class="container ">
       
        <div class="row ">
            <div class="col-8 mx-auto">
            <h3>Add New Currency</h3>
  <form acttion="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleFormControlInput1">Currency Name</label>
    <input type="currency" class="form-control" name="name" id="exampleFormControlInput1" >
  </div>
  <br>
  <div class="form-group">
    <label for="exampleFormControlInput1">Currency Icon</label>
    <input type="file" class="form-control" name="image" id="exampleFormControlInput1" >
  </div>  
  <br>
  <div class="form-group">
    <label for="exampleFormControlInput1">Buy Price</label>
    <input type="currency" class="form-control" name="b_price" id="exampleFormControlInput1" >
  </div>  
  <br>
  <div class="form-group">
    <label for="exampleFormControlInput1">Sale Price</label>
    <input type="currency" class="form-control" name="s_price" id="exampleFormControlInput1" >
  </div>
  <br>
  <div class="form-group">
  <label for="exampleFormControlInput1">Description</label>
    <input type="currency" class="form-control" name="description" id="exampleFormControlInput1" >
  </div>  
  <br>
  <div class="form-group" >
 
  <button class="btn btn-primary" style="float:right">Add Now</button>
     </div>  
</form>
            </div>
        </div>
    </div>
  </section>
</div>

 



<?php
require 'footer.php';

?>