<?php
// error_reporting(E_ERROR | E_PARSE);
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the login page
    header("Location: login.php");
    exit;
}

require_once '../conn.php';

    // Fetch the row from 'forex' table based on the ID
    $sql = "SELECT * FROM admin WHERE id = 1";
    $result = $conn->query($sql);

    $row = $result->fetch_assoc();
    $msg ='';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if old password is correct
        $oldPassword = $_POST['old_password'];
        $newPassword = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];
    

     
            
        
            if ($oldPassword == $row['password']) {
                // Check if new password matches confirm password
                if ($newPassword === $confirmPassword) {
                    // Update password in the database
                    
                    $updateSql = "UPDATE admin SET password = '$newPassword' WHERE id = 1";
                    if ($conn->query($updateSql) === TRUE) {
                        $msg = '<div class="alert alert-success" role="alert">Password updated successfully.</div>';
                    } else {
                        $msg = '<div class="alert alert-danger" role="alert">Error updating password</div>';
                    }
                } else {
                    $msg = '<div class="alert alert-danger" role="alert">New password and confirm password do not match.</div>';
                }
            } else {
                $msg = '<div class="alert alert-danger" role="alert">Old password is incorrect.</div>';
            }
        
    } 

   


// Close database connection
$conn->close();
require 'header.php';
?>

<!-- HTML form for editing data -->
<div class="blog padding-top padding-bottom section-bg-color">
    <section>
        <div class="container">
        <div class="row">
        <?php echo $msg; ?>
    <div class="col-md-6 mb-4 mb-md-0 mr-md-2" style="border: 1px solid black; padding: 5%; ">
        <h3>Admin Profile</h3>
        <!-- <img src="logo.png" alt="" class="img-fluid"> -->
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo $row['name']; ?>">
            </div>
            <br>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" value="<?php echo $row['email']; ?>">
            </div>
            <br>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" value="<?php echo $row['password']; ?>">
            </div>
        </form>
    </div>

    <div class="col-md-6 col-md-6 mb-4 mb-md-0 mr-md-2" style="border: 1px solid black; padding: 5%;">
       
        <h3>Change Password</h3>
       
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="old_password">Old Password</label>
        <input type="password" class="form-control" name="old_password" required>
    </div>
    <br>
    <div class="form-group">
        <label for="new_password">New Password</label>
        <input type="password" class="form-control" name="new_password" required>
    </div>
    <br>
    <div class="form-group">
        <label for="confirm_password">Confirm Password</label>
        <input type="password" class="form-control" name="confirm_password" required>
    </div>
    <br>
    <div class="form-group">
        <button type="submit" class="btn btn-primary">Change Password</button>
    </div>
</form>

    </div>
</div>

        </div>
    </section>
</div>

<?php
require 'footer.php';
?>
