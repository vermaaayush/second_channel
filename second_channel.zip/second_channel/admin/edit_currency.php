<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the login page
    header("Location: login.php");
    exit;
}

error_reporting(E_ERROR | E_PARSE);

require_once '../conn.php';

if (isset($_GET['id'])) {
    // Get the ID value from the URL parameter
    $id = $_GET['id'];

    // Fetch the row from 'forex' table based on the ID
    $sql = "SELECT * FROM forex WHERE id = $id";
    $result = $conn->query($sql);

    $row = $result->fetch_assoc();

    // Check if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Define variables to store form data
        $currencyName = $_POST['name'];
        $buyPrice = $_POST['b_price'];
        $salePrice = $_POST['s_price'];
        $description = $_POST['description'];

        // Check if new image file is uploaded
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            // Get file details
            $fileName = $_FILES['image']['name'];
            $fileTmpName = $_FILES['image']['tmp_name'];
            $fileType = $_FILES['image']['type'];
            $fileSize = $_FILES['image']['size'];

            // Define folder path to store uploaded files
            $uploadFolder = 'flag/';

            // Move uploaded file to folder
            $filePath = $uploadFolder . $fileName;
            if (move_uploaded_file($fileTmpName, $filePath)) {
                // Update data in database including new image path
                $sqlUpdate = "UPDATE forex SET name = '$currencyName', image = '$filePath', b_price = $buyPrice, s_price = $salePrice, description = '$description' WHERE id = $id";
                if ($conn->query($sqlUpdate) === TRUE) {
                    $error= '<div class="alert alert-success" role="alert">Data updated successfully.</div>';
                } else {
                    $error= '<div class="alert alert-danger" role="alert">Error updating data: ' . $conn->error . '</div>';
                }
            } else {
                $error= '<div class="alert alert-danger" role="alert">Error uploading file.</div>';
            }
        } else {
            // Update data in database without changing image path
            $sqlUpdate = "UPDATE forex SET name = '$currencyName', b_price = $buyPrice, s_price = $salePrice, description = '$description' WHERE id = $id";
            if ($conn->query($sqlUpdate) === TRUE) {
                $error= '<div class="alert alert-success" role="alert">Data updated successfully.</div>';
                header("refresh:3;url=dashboard.php");
            } else {
                $error= '<div class="alert alert-danger" role="alert">Error updating data: ' . $conn->error . '</div>';
            }
        }
    }
} else {
    $error= "ID parameter is missing.";
}

// Close database connection
$conn->close();
require 'header.php';
?>

<!-- HTML form for editing data -->
<div class="blog padding-top padding-bottom section-bg-color">
    <section>
        <div class="container">
            <div class="row">
                <div class="col-8 mx-auto">
                    <?php echo $error; ?>
                    <h3>Edit Currency</h3>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Currency Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo $row['name']; ?>" id="exampleFormControlInput1">
                        </div>
                        <br>
                        <div class="form-group">
                            <img src="<?php echo $row['image']; ?>" alt="Current Image" width="50px" height="50px"><br>
                            <label for="exampleFormControlInput1">New Currency Icon (Optional)</label>
                            <input type="file" class="form-control" name="image" id="exampleFormControlInput1">
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Buy Price</label>
                            <input type="text" class="form-control" name="b_price" value="<?php echo $row['b_price']; ?>" id="exampleFormControlInput1">
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Sale Price</label>
                            <input type="text" class="form-control" name="s_price" value="<?php echo $row['s_price']; ?>" id="exampleFormControlInput1">
                        </div>
                        <br>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Description</label>
                            <input type="text" class="form-control" name="description" value="<?php echo $row['description']; ?>" id="exampleFormControlInput1">
                        </div>
                        <br>
                        <br>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary" style="float: right">Update Data</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<?php
require 'footer.php';
?>
