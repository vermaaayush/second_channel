<!DOCTYPE html>
<html lang="en" data-bs-theme="light">


<!-- blog-sidebar.html  18:07:44 GMT -->
<head>
  <title>Admin Panel - Second Channel</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  

  <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/x-icon">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/aos.css">
  <link rel="stylesheet" href="../assets/css/all.min.css">

  <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css">
   

  
  <link rel="stylesheet" href="../assets/css/style.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">


  <style>
        /* Custom styles for table */
        .table th, .table td {
            text-align: center;
        }

        .marquee-container {
        width: 100%;
        overflow: hidden;
        white-space: nowrap;
        margin: auto;
        background-color:#00d09452;
    }

  

    .currency-item {
        display: inline-block;
        margin-right: 20px; /* Adjust margin as needed */
        color:black;
        padding:1%;
        margin-top:0.5%;
    }

    * {
    font-family: "Poppins", sans-serif;
  font-weight: 600;
  font-style: normal;
}

body {
  font-family: "Poppins", sans-serif;
  font-weight: 600;
  font-style: normal;
}

.xx{
  font-family: "Poppins", sans-serif;
  font-weight: 600;
  font-style: normal;
}
    </style>
</head>

<body>
<div class="lightdark-switch">
    <span style="display:none" class="switch-btn" id="btnSwitch"><img src="assets/images/icon/moon.svg" alt="light-dark-switchbtn"
        class="swtich-icon"></span>
  </div>
  <!-- ===============>> Preloader start here <<================= -->
  <div class="preloader">
    <img src="../assets/images/logo/preloader.png" alt="preloader icon"  width="100px">
  </div>
  <!-- ===============>> Preloader end here <<================= -->

  <section>
  
  

  </section>

  
  <!-- ===============>> Header section start here <<================= -->
  <header class="header-section bg-color-3">
    <div class="header-bottom">
      <div class="container">
        <div class="header-wrapper">
          <div class="logo">
            <a href="dashboard.php">
              <img class="dark" src="logo.png" alt="logo" width="280px">
            </a>
          </div>
          <div class="menu-area">
          <ul class="menu menu--style1">
    <li>
        <a href="dashboard.php">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
    </li>
    <li>
        <a href="add_new.php">
            <i class="fas fa-plus-circle"></i> Add New
        </a>
    </li>
    <li>
        <a href="advertisement.php">
            <i class="fas fa-plus-circle"></i> Advertisement
        </a>
    </li>
    <li>
        <a href="profile.php">
            <i class="fas fa-user"></i> Profile
        </a>
    </li>
    <li>
        <a href="logout.php">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </li>
</ul>


          </div>
          

              <!-- toggle icons -->
              <div class="header-bar d-lg-none header-bar--style1">
                <span></span>
                <span></span>
                <span></span>
              </div>
           
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- ===============>> Header section end here <<================= -->