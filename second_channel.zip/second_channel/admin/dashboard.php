
<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the login page
    header("Location: login.php");
    exit;
}

require_once '../conn.php';
require 'header.php';
?>




  <!-- ===============>> Blogs section start here <<================= -->
  <div class="blog padding-bottom section-bg-color">
 <br>
  <section>

   <div class="marquee-container">
   <div class="marquee-content">
   <marquee scrollamount="10">
       <?php
      

       $sql = "SELECT * FROM forex";
       $result = $conn->query($sql);
         
       if ($result->num_rows > 0) {
           while ($row = $result->fetch_assoc()) {
               echo '<div class="currency-item"><img src="' . $row['image'] . '" alt="' . $row['image'] . '"> <strong style="color:black">' . $row['name'] . '</strong> <span style="color:green">BUY:</span> ' . $row['b_price'] . ' / <span style="color:red">SALE:</span> ' . $row['s_price'] . '</div>';
           }
       } else {
           echo '<div class="currency-item">No data found.</div>';
       }

      
       ?>
       </marquee>
   </div>
</div>
 </section>
 <br>
  <section>
    <div class="container ">
        <div class="row">
            <div class="col-md-12"><div class="blog__item" >
                  <div class="blog__item-inner blog__item-inner--style2">
                   

                    <div class="blog__content">
                      <div class="blog__meta">
                        <span class="blog__meta-tag blog__meta-tag--style1" id="datetime"></span>
                        
                      </div>
                      <div class="d-flex flex-column flex-md-row justify-content-md-between align-items-center">
  <h5 class="10 style2 mb-2 mb-md-0"><a href="blog-details.html">Currency Exchange Rates</a></h5>
  <p><a href="quick_edit.php" class="btn btn-success">Quick Edit</a></p>
</div>

                      
                      <!-- <p class="mb-15">Lorem ipsum dolor sit amet Iaculis suspendisse semper m dolor amet Iaculis lectus
                        ipsum dolor sit amet Iaculis suspendisse semper amet lectus...</p> -->

                        <div class="container mt-5">
                        <div class="row">
    <div class="col-12">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Currency</th>
                        <th>Buy Rates</th>
                        <th>Sale Rates</th>
                        <th>Description</th>
                        <th>View</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM forex";
                    $result = $conn->query($sql);
                    if ($result->num_rows > 0) {
                        // Loop through each row and generate HTML content
                        while ($row = $result->fetch_assoc()) {
                            echo '<tr>';
                            echo '<td><img src="' . $row['image'] . '" alt=""><strong> ' . $row['name'] . '</strong></td>';
                            echo '<td>' . $row['b_price'] . '</td>';
                            echo '<td>' . $row['s_price'] . '</td>';
                            echo '<td><textarea rows="2" class="form-control">' . $row['description'] . '</textarea></td>';

                            echo '<td><a href="edit_currency.php?id=' . $row['id'] . '" class="btn btn-primary"><i class="fas fa-cogs"></i> Manage</a></td>';
                            echo '<td><a href="delete.php?id=' . $row['id'] . '" onclick="return confirm(\'Are you sure you want to delete this record?\');" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Delete</a></td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="5">No data found.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
                    </div>
                  </div>
                </div></div>
        </div>
    </div>
  </section>
</div>

 

<script>
        // Function to update the date and time every second
        function updateDateTime() {
            var currentDate = new Date();
            var dateTimeString = currentDate.toLocaleString(); // Convert date to string in local time format
            document.getElementById('datetime').innerText = "Date and Time: " + dateTimeString;
        }

        // Update the date and time initially
        updateDateTime();

        // Update the date and time every second
        setInterval(updateDateTime, 1000);
</script>


<?php
require 'footer.php';

?>