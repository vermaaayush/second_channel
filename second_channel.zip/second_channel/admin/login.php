<?php
session_start(); // Start session for storing login status

// Include database connection file
require_once '../conn.php';

// Check if the user is already logged in, redirect to dashboard if true
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php");
    exit;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize inputs
    $username = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Query to retrieve admin from database
      // $sql = "SELECT * FROM admin WHERE email = '$username'";
   $sql = "select * from admin where email = '$username'";
    // Execute query
    $result = mysqli_query($conn, $sql);
   
    // Check if admin exists and verify password
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        if ( $password ==  $row['password']) {
            // Password is correct, start session and redirect to dashboard
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            header("Location: dashboard.php");
            exit;
        } else {
            // Password is incorrect

            $error = '<div class="alert alert-danger" role="alert">Invalid Password.</div>';
            
        }
    } else {
        // Admin not found
     
        $error = '<div class="alert alert-danger" role="alert">Invalid Email or Password.</div>';
    }

    // Free result set
    mysqli_free_result($result);
}

?>










<!DOCTYPE html>
<html lang="en" data-bs-theme="light">


<!-- signin.html  18:07:49 GMT -->
<head>
  <title>Login -  Second Channel</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  


  <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/x-icon">

  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/aos.css">
  <link rel="stylesheet" href="../assets/css/all.min.css">

  <link rel="stylesheet" href="../assets/css/swiper-bundle.min.css">



  <!-- main css for template -->
  <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

  <!-- ===============>> Preloader start here <<================= -->
  <div class="preloader">
    <img src="../assets/images/logo/preloader.png" alt="preloader icon" width="100px">
  </div>
  <!-- ===============>> Preloader end here <<================= -->



  <!-- ===============>> light&dark switch start here <<================= -->
  <div class="lightdark-switch" style="display:none">
    <span class="switch-btn" id="btnSwitch"><img src="assets/images/icon/moon.svg"
        class="swtich-icon"></span>
  </div>
  <!-- ===============>> light&dark switch start here <<================= -->

  <!-- ===============>> account start here <<================= -->
  <section class="account  padding-bottom sec-bg-color2">
    <div class="container" >
      <br>
      <p style="text-align:center"><img src="logo.png" alt="" width="40%"></p>
      <br>
      <div class="account__wrapper" >
        <div class="row">
          <div class="col-6 mx-auto">
            <div class="account__content account__content--style1" style="padding:5%">
              
            <?php if (isset($error)): ?>
                 <p style="color:red"><?php echo $error; ?></p>
            <?php endif; ?>
               <h3>Admin Login</h3>
              <!-- account form -->
              <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="account__form needs-validation" method="post" >
                <div class="row ">
                  <div class="col-12">
                    <div>
                      <label for="account-email" class="form-label">Email</label>
                      <input type="email" class="form-control" name="email" id="account-email" placeholder="Enter your email"
                        required>
                    </div>
                  </div>
                 
                  <div class="col-12">
                    <div class="form-pass">
                      <br>
                      <label for="account-pass" class="form-label">Password</label>
                      <input type="password" class="form-control showhide-pass" name="password" id="account-pass" placeholder="Password"
                        required>

                    </div>
                  </div>
                </div>


                <button type="submit" class="trk-btn trk-btn--border trk-btn--primary d-block mt-4">Log In</button>
              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
   
  </section>







  <script src="../assets/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/all.min.js"></script>
  <script src="../assets/js/swiper-bundle.min.js"></script>
  <script src="../assets/js/aos.js"></script>
  <script src="../assets/js/fslightbox.js"></script>
  <script src="../assets/js/purecounter_vanilla.js"></script>



  <script src="../assets/js/custom.js"></script>


</body>


<!-- signin.html  18:07:49 GMT -->
</html>