<footer class="footer ">
    <div class="container">
      <div class="footer__wrapper">
        <div class="footer__top footer__top--style1">
          <div class="row gy-5 gx-4">
            <div class="col-md-6">
              <div class="footer__about">
                <a href="index.php" class="footer__about-logo"><img src="../assets/images/logo/logo-dark.png"
                    alt="Logo" width="100%"></a>
              
              </div>
            </div>
            
            
            
          </div>
        </div>
        <div class="footer__bottom">
          <div class="footer__end">
            <div class="footer__end-copyright">
              <p class=" mb-0">© 2024 All Rights Reserved By Second Channel</p>
            </div>
            <div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer__shape">
      <span class="footer__shape-item footer__shape-item--1"><img src="../assets/images/footer/1.png"
          alt="shape icon"></span>
      <span class="footer__shape-item footer__shape-item--2"> <span></span> </span>
    </div>
  </footer>
  <!-- ===============>> footer end here <<================= -->



  <!-- ===============>> scrollToTop start here <<================= -->
  <a href="#" class="scrollToTop scrollToTop--style1"><i class="fa-solid fa-arrow-up-from-bracket"></i></a>
  <!-- ===============>> scrollToTop ending here <<================= -->


  <!-- vendor plugins -->

  <script src="../assets/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/all.min.js"></script>
  <script src="../assets/js/swiper-bundle.min.js"></script>
  <script src="../assets/js/aos.js"></script>
  <script src="../assets/js/fslightbox.js"></script>
  <script src="../assets/js/purecounter_vanilla.js"></script>



  <script src="../assets/js/custom.js"></script>


</body>


<!-- blog-sidebar.html  18:07:45 GMT -->
</html>