<?php
error_reporting(0);
ini_set('display_errors', 0);
require_once '../conn.php';
// error_reporting(E_ERROR | E_PARSE);
session_start();

$sql = "SELECT * FROM advertisement WHERE id = 1";
$adver = $conn->query($sql);
$adverx = $adver->fetch_assoc();



// Check if the user is not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the login page
    header("Location: login.php");
    exit;
}






if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $link = $_POST['link'];
    $status = $_POST["status"];

    // Check if file is uploaded
    if (isset($_FILES['adver_image']) && $_FILES['adver_image']['error'] === UPLOAD_ERR_OK) {
        // Get file details
        $fileName = $_FILES['adver_image']['name'];
        $fileTmpName = $_FILES['adver_image']['tmp_name'];
        $fileType = $_FILES['adver_image']['type'];
        $fileSize = $_FILES['adver_image']['size'];
       
        // Define folder path to store uploaded files
        $uploadFolder = 'flag/';

        // Move uploaded file to folder
        $filePath = $uploadFolder . $fileName;
        if (move_uploaded_file($fileTmpName, $filePath)) {
            // File moved successfully, update data in database including image path
            $sql = "UPDATE advertisement 
                    SET image = '$filePath', link = '$link', status = '$status'
                    WHERE id = 1";
            if ($conn->query($sql) === TRUE) {
                // Redirect to dashboard after updating data in database
                header("Location: advertisement.php");
                exit;
            } else {
                echo "Error updating data: " . $conn->error;
            }
        } else {
            echo "Error uploading file.";
        }
    } else {
        // No file uploaded, update data in database without changing image
        $sql = "UPDATE advertisement 
                SET link = '$link', status = '$status'
                WHERE id = 1";
        if ($conn->query($sql) === TRUE) {
            // Redirect to dashboard after updating data in database
            header("Location: advertisement.php");
            exit;
        } else {
            echo "Error updating data: " . $conn->error;
        }
    }
}




require 'header.php';
?>

<!-- HTML form for editing data -->
<div class="blog padding-top padding-bottom section-bg-color">
    <section>
        <div class="container">
        <div class="row">
       
    <div class="col-md-6 mb-4 mb-md-0 mr-md-2" style="border: 1px solid black; padding: 5%; ">
        <h3>Manage Advertisement</h3>
        <!-- <img src="logo.png" alt="" class="img-fluid"> -->
        <form acttion="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="name">Image</label>
        <input type="file" class="form-control" name="adver_image" >
    </div>
    <br>
    <div class="form-group">
        <label for="email">Social Link</label>
        <input type="text" class="form-control" name="link" value="<?php echo $adverx['link'] ?>"> 
    </div> 
    <br>
    <div class="form-group">
    <div class="form-check">
        <input class="form-check-input" type="radio" id="enable" name="status" value="1" <?php if ($adverx['status'] == 1) echo "checked"; ?>>
        <label class="form-check-label" for="enable">
            Enable 
        </label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="radio" id="disable" name="status" value="0" <?php if ($adverx['status'] == 0) echo "checked"; ?>>
        <label class="form-check-label" for="disable">
            Disable 
        </label>
    </div>
    </div>

    <br>
    <div class="form-group">
       <button type="submit" class="btn btn-primary">Save Now</button>
    </div>
</form>
    </div>

    <div class="col-md-6 col-md-6 mb-4 mb-md-0 mr-md-2" style="border: 1px solid black; padding: 5%;">
       
         <img src="<?php echo $adverx['image'] ?>" width="100%">
        
    </div>
</div>

        </div>
    </section>
</div>

<?php
require 'footer.php';
?>
