<?php
session_start();
require_once '../conn.php';
require 'header.php';

// Check if the user is not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Redirect to the login page
    header("Location: login.php");
    exit;
}

$updateSuccess1 = false;
$updateSuccess2 = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input data
    $b_prices = $_POST['b_price'];
    $s_prices = $_POST['s_price'];
    $ids = $_POST['id'];

    
    for ($i = 0; $i < count($b_prices); $i++) {
       
       
        $id = mysqli_real_escape_string($conn, $ids[$i]);
        $b_price = mysqli_real_escape_string($conn, $b_prices[$i]);
        $sql = "UPDATE forex SET b_price='$b_price' WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            $updateSuccess1 = true;
        } else {
            echo "Error updating buy price: " . $conn->error . "<br>";
        }
    }

  
    for ($i = 0; $i < count($s_prices); $i++) {
        

        // Update the forex table with new sell price
        $id = mysqli_real_escape_string($conn, $ids[$i]);
        $s_price = mysqli_real_escape_string($conn, $s_prices[$i]);
        $sql = "UPDATE forex SET s_price='$s_price' WHERE id='$id'";
        if ($conn->query($sql) === TRUE) {
            $updateSuccess2 = true;
        } else {
            echo "Error updating sale price: " . $conn->error . "<br>";
        }
    }

    
}

if ($updateSuccess1 && $updateSuccess2) {
    $msg = '<div class="alert alert-success" role="alert">Buy and sell prices updated successfully.</div>';
    echo $msg;
}
?>

<!-- HTML content starts here -->
<div class="blog padding-bottom section-bg-color">
    <br>
    <section>
        <div class="container">
            <div class="row">
                <div>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Currency</th>
                                    <th>Buy Rates</th>
                                    <th>Sale Rates</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM forex";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    // Loop through each row and generate HTML content
                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        echo '<td><strong>' . $row['name'] . '</strong></td>';
                                        echo '<td><input type="text" name="b_price[]" value="' . $row['b_price'] . '"></td>';
                                        echo '<td><input type="text" name="s_price[]" value="' . $row['s_price'] . '"></td>';
                                        echo '<input type="hidden" name="id[]" value="' . $row['id'] . '">';
                                        echo '</tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="3">No data found.</td></tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                        <p style="text-align:center"><button class="btn btn-primary" type="submit">Update Now</button></p>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- End of HTML content -->

<?php
require 'footer.php';
?>
