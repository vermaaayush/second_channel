<?php
// Include database connection file
require_once '../conn.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // SQL query to delete the record with the specified ID
    $sql = "DELETE FROM forex WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Record deleted successfully, redirect to a success page or back to the previous page
        header("Location: dashboard.php");
        exit;
    } else {
        // Error deleting record, display an error message or redirect to an error page
        header("Location: dashboard.php");
        exit;
    }
} else {
    // ID parameter is missing, handle the error or redirect to an error page
    header("Location: dashboard.php");
    exit;
}

// Close database connection
$conn->close();
?>
