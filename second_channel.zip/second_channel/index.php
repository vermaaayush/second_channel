<?php
 require_once 'conn.php';
?>




<!DOCTYPE html>
<html lang="en" data-bs-theme="light">


<!-- index.php  18:06:53 GMT -->
<head>
  <title>Second Channel</title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  
 


  <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">

  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/aos.css">
  <link rel="stylesheet" href="assets/css/all.min.css">

  <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- main css for template -->
  <link rel="stylesheet" href="assets/css/style.css">

  <style>
    td,th{
   
    }
    table{
      border:6px solid grey;
    }

    .marquee-container {
        width: 100%;
        overflow: hidden;
        white-space: nowrap;
        margin: auto;
        background-color:#092e73;
       
    }

  

    .currency-item {
        display: inline-block;
        margin-right: 20px; /* Adjust margin as needed */
        color:white ;
        padding:1%;
        margin-top:0.5%;
    }

    .whatsapp_float{
  position: fixed;
  bottom: 27px;
  left: 20px;
  z-index: 10;
}

.ad-banner {
    display: flex;
    justify-content: center;
    align-items: center;

    
  }

  .ad-image {
    max-width: 100%;
    height: auto;
  }

  .table-container {
    overflow-x: auto; /* Enable horizontal scrolling */
  }

  * {
    font-family: "Poppins", sans-serif;
  font-weight: 600;
  font-style: normal;
}

body {
  font-family: "Poppins", sans-serif;
  font-weight: 600;
  font-style: normal;
}

.xx{
  font-family: "Poppins", sans-serif;
  font-weight: 600;
  font-style: normal;
}
  </style>
</head>
<!--Start of Tawk.to Script-->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/65fde850a0c6737bd123c229/1hpjt6upc';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!--End of Tawk.to Script-->
<body>

  <!-- ===============>> Preloader start here <<================= -->
  <div class="preloader">
    <img src="assets/images/logo/preloader.png" alt="preloader icon" width="100px">
  </div>
  <!-- ===============>> Preloader end here <<================= -->



  <!-- ===============>> light&dark switch start here <<================= -->
  <div class="lightdark-switch">
    <span class="switch-btn" id="btnSwitch"><img src="assets/images/icon/moon.svg" alt="light-dark-switchbtn"
        class="swtich-icon"></span>
  </div>
  <!-- ===============>> light&dark switch start here <<================= -->





  <!-- ===============>> Header section start here <<================= -->
  <header class="header-section header-section--style2">
    <div class="header-bottom">
      <div class="container">
        <div class="header-wrapper">
          <div class="logo">
            <a href="index.php">
              <img class="dark" src="assets/images/logo/logo.png" alt="logo" width="280px">
            </a>
          </div>
          <div class="menu-area">
            <ul class="menu menu--style1">
              
            </ul>

          </div>
          <div class="header-action">
            <div class="menu-area">
             
         
              <div class="header-bar d-lg-none header-bar--style1" >
              
              </div>
            </div>
          </div>
        
        </div>
      </div>
    </div>
  </header>
  <!-- ===============>> Header section end here <<================= -->





  <!-- ===============>> Banner section start here <<================= -->
  <section class="banner banner--style1">
    <div class="banner__bg">
      <div class="banner__bg-element">
        <img src="assets/images/banner/home1/bg.png"  class="dark d-none d-lg-block">
        <span class="bg-color d-lg-none"></span>
      </div>
    </div>
    <div class="container">
      <div class="banner__wrapper">
        <div class="row gy-5 gx-4" >
          <div class="col-lg-6 col-md-5">
            <div class="banner__content" data-aos="fade-right" data-aos-duration="1000">
              <div class="banner__content-coin">
                <img src="assets/images/banner/home1/3.png" alt="coin icon">
              </div>
              <h1 class="banner__content-heading xx" >Manage Your Funds <span>SECURELY</span></h1> 
              <p class="banner__content-moto xx">Managing your funds efficiently, securely and proficiently
              </p>
              <div class="banner__btn-group btn-group">
                <a href="https://wa.me/971567953214" class="trk-btn trk-btn--primary trk-btn--arrow">Contact Us Now
                  <span><i class="fa-solid fa-arrow-right"></i></span> </a>

              </div>
              
            </div>
          </div>
          <div class="col-lg-6 col-md-5">
  <div class="banner__content" data-aos="fade-right" data-aos-duration="1000">
    <div class="blog__meta">
      <span class="blog__meta-tag blog__meta-tag--style1" id="datetime"></span>
    </div>
    <div class="table-responsive"> <!-- Add the table-responsive class for mobile responsiveness -->
      <table class="table table-bordered xx">
        <thead>
          <tr>
            <th>Country/Currency</th>
            <th>Buy Rates</th>
            <th>Sale Rates</th>
          </tr>
        </thead>
        <tbody>
          <?php
         
          $sql = "SELECT * FROM forex";
          $result = $conn->query($sql);
          if ($result->num_rows > 0) {
            // Loop through each row and generate HTML content
            while ($row = $result->fetch_assoc()) {
              echo '<tr>';
              echo '<td ><img src="admin/' . $row['image'] . '" alt="sd"><strong> ' . $row['name'] . '</strong></td>';
              echo '<td style="color:green">' . $row['b_price'] . '</td>';
              echo '<td style="color:red">' . $row['s_price'] . '</td>';
              echo '</tr>';
            }
          } else {
            echo '<tr><td colspan="3">No data found.</td></tr>';
          }
          ?>
          
        </tbody>
        
      </table>
      <span style="font-size: 12px;">*T&C Apply</span>
    </div>
  </div>
</div>

      </div>
    </div>
    <div class="banner__shape">
      
      <span class="banner__shape-item banner__shape-item--1"><img src="assets/images/banner/home1/4.png"
          alt="shape icon"></span>
    </div>

  </section>
  <!-- ===============>> Banner section end here <<================= -->


  <section>
   
    <div class="marquee-container">
    <div class="marquee-content">
    <marquee scrollamount="10">
        <?php
       

        $sql = "SELECT * FROM forex";
        $result = $conn->query($sql);
          
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="currency-item xx"><img src="admin/' . $row['image'] . '" alt="' . $row['image'] . '"> ' . $row['name'] . ' <span style="color:green">BUY:</span> ' . $row['b_price'] . ' / <span style="color:red">SALE:</span> ' . $row['s_price'] . '</div>';
            }
        } else {
            echo '<div class="currency-item">No data found.</div>';
        }

       
        ?>
        </marquee>
    </div>
</div>
  </section>

  <br>
  <!-- ===============>> partner section start here <<================= -->
  <section>
   <div class="container">
    <div class="row">
      <div class="col-lg-9 col-12 mx-auto">
        <div class="ad-banner">
        <?php
require_once 'conn.php';

$sql = "SELECT * FROM advertisement WHERE id = 1";
$adver = $conn->query($sql);
$adverx = $adver->fetch_assoc();

if ($adverx['status'] == 1) {
    echo '<p style="text-align:center"><a href=' . $adverx['link'] .'><img src="admin/' . $adverx['image'] . '" alt="Advertisement" class="ad-image"></a>  </p>';
}

$conn->close();
?>
       
        </div>
      </div>
    </div>
  </div>
  </section>




  <!-- ===============>> About section start here <<================= -->
  <section class="about about--style1 " style="margin-top:-80px">
    <div class="container">
      <div class="about__wrapper">
        <div class="row gx-5  gy-4 gy-sm-0  align-items-center">
          <div class="col-lg-6">
            <div class="about__thumb pe-lg-5" data-aos="fade-right" data-aos-duration="800">
              <div class="about__thumb-inner">
                <div class="about__thumb-image floating-content">
                  <img class="dark" src="assets/images/about/1.png" alt="about-image">
                  <div class="floating-content__top-left" data-aos="fade-right" data-aos-duration="1000">
                    <div class="floating-content__item">
                      <h3> <span class="purecounter xx" data-purecounter-start="0" data-purecounter-end="7">7</span>
                        Years
                      </h3>
                      <p class="xx">Consulting Experience</p>
                    </div>
                  </div>
                  <div class="floating-content__bottom-right" data-aos="fade-right" data-aos-duration="1000">
                    <div class="floating-content__item">
                      <h3> <span class="purecounter xx" data-purecounter-start="0" data-purecounter-end="5">5K</span>K+
                      </h3>
                      <p class="xx">Satisfied Customers</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="about__content" data-aos="fade-left" data-aos-duration="800">
              <div class="about__content-inner">
                <h2 class="xx">Meet <span>our company</span> unless miss the opportunity </h2>

                <p class="mb-0 xx">Welcome to Second channel, where expert fund management meets personalized service. Our dedicated team is committed to efficiently and securely managing our clients' funds, ensuring peace of mind and optimal financial outcomes. With a focus on transparency, innovation, and tailored strategies, we strive to exceed expectations and build lasting partnerships with our clients. Trust us for dependable and proficient management of your investments.</p>
                <!-- <a href="about.html" class="trk-btn trk-btn--border trk-btn--primary">Explore More </a> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> About section start here <<================= -->





  <!-- ===============>> feature section start here <<================= -->
  <section class="feature feature--style1 padding-bottom padding-top bg-color">
    <div class="container">
      <div class="feature__wrapper">
        <div class="row g-5 align-items-center justify-content-between">
          <div class="col-md-6 col-lg-5">
            <div class="feature__content" data-aos="fade-right" data-aos-duration="800">
              <div class="feature__content-inner">
                <div class="section-header">
                  <h2 class="mb-10 mt-minus-5 xx"> <span>benefits </span>We offer</h2>
                  <!-- <p class="mb-0">
                    Unlock the full potential of our product with our amazing features and top-notch.
                  </p> -->
                </div>

                <div class="feature__nav">
                  <div class="nav nav--feature flex-column nav-pills" id="feat-pills-tab" role="tablist"
                    aria-orientation="vertical">
                    <div class="nav-link " id="feat-pills-one-tab" data-bs-toggle="pill"
                      data-bs-target="#feat-pills-one" role="tab" aria-controls="feat-pills-one" aria-selected="true">
                      <div class="feature__item">
                        <div class="feature__item-inner">
                          <div class="feature__item-content">
                            <h6 >UPDATED RATE CHART</h6>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="nav-link " id="feat-pills-one-tab" data-bs-toggle="pill"
                      data-bs-target="#feat-pills-one" role="tab" aria-controls="feat-pills-one" aria-selected="true">
                      <div class="feature__item">
                        <div class="feature__item-inner">
                          <div class="feature__item-content">
                            <h6>SAFETY & SECURITY OF FUNDS</h6>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="nav-link " id="feat-pills-one-tab" data-bs-toggle="pill"
                      data-bs-target="#feat-pills-one" role="tab" aria-controls="feat-pills-one" aria-selected="true">
                      <div class="feature__item">
                        <div class="feature__item-inner">
                          <div class="feature__item-content">
                            <h6>24 X 7 ASSISTANCE</h6>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="nav-link " id="feat-pills-one-tab" data-bs-toggle="pill"
                      data-bs-target="#feat-pills-one" role="tab" aria-controls="feat-pills-one" aria-selected="true">
                      <div class="feature__item">
                        <div class="feature__item-inner">
                          <div class="feature__item-content">
                            <h6>TRANSPARANCY OF PROCESS</h6>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-6">
            <div class="feature__thumb pt-5 pt-md-0" data-aos="fade-left" data-aos-duration="800">
              <div class="feature__thumb-inner">
                <div class="tab-content" id="feat-pills-tabContent">
                  <div class="tab-pane fade show active" id="feat-pills-one" role="tabpanel"
                    aria-labelledby="feat-pills-one-tab" tabindex="0">
                    <div class="feature__image floating-content">
                      <img src="assets/images/feature/1.png" alt="Feature image">
                      <div class="floating-content__top-right floating-content__top-right--style2" data-aos="fade-left"
                        data-aos-duration="1000">
                        <div class="floating-content__item floating-content__item--style2 text-center">
                        
                          <p class="style2">Systematic Approach</p>
                        </div>
                      </div>
                      <div class="floating-content__bottom-left floating-content__bottom-left--style2"
                        data-aos="fade-left" data-aos-duration="1000">
                        <div class="floating-content__item floating-content__item--style3  d-flex align-items-center">
                          <h3 class="style2"> <span class="purecounter" data-purecounter-start="0"
                              data-purecounter-end="100">100%</span>%
                          </h3>
                          <p class="ms-3 style2"> Gaurantee of Safety</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="feature__shape">
      <span class="feature__shape-item feature__shape-item--1"><img src="assets/images/feature/shape/1.png"
          alt="shape-icon"></span>
      <span class="feature__shape-item feature__shape-item--2"> <span></span> </span>
    </div>
  </section>
  <!-- ===============>> feature section end here <<================= -->




  <!-- ===============>> Service section start here <<================= -->
  <section class="service padding-top padding-bottom">
    <div class="section-header section-header--max50">
      <h2 class="mb-10 mt-minus-5 xx"><span>SERVICES </span>We offer</h2>
      <!-- <p>We offer the best services around - from installations to repairs, maintenance, and more!</p> -->
    </div>
    <div class="container">
      <div class="service__wrapper">
        <div class="row g-4 align-items-center">
          <div class="col-sm-6 col-md-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="800">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/1.png" alt="service-icon">
                </div>
                <div>
                  <h5 class="xx"> Major digital & physical currency conversions </h5>
                  
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1000">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/2.png" alt="service-icon">
                </div>
                <div>
                  <h5 class="xx"> Quote your order to get instantly deals </h5>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1200">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/3.png" alt="service-icon">
                </div>
                <div>
                  <h5 class="xx"> Professialy equipped team to handle your query </h5>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="800">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/4.png" alt="service-icon">
                </div>
                <div>
                  <h5 class="xx"> Instant Confirmation </h5>
                  <br>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1000">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/5.png" alt="service-icon">
                </div>
                <div>
                  <h5 class="xx"> Professional counsling for your trade </h5>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-lg-4">
            <div class="service__item service__item--style1" data-aos="fade-up" data-aos-duration="1200">
              <div class="service__item-inner text-center">
                <div class="service__item-thumb mb-30">
                  <img class="dark" src="assets/images/service/6.png" alt="service-icon">
                </div>
                <div>
                  <h5 class="xx"> No volume Restrictions </h5>
                  <br>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> Service section start here <<================= -->




  <!-- ========== Roadmap Section start Here========== -->
  <section class="roadmap roadmap--style1 padding-top  padding-bottom bg-color" id="roadmap">
    <div class="container">
      <div class="section-header section-header--max50">
        <h2 class="mb-10 mt-minus-5 xx">PROCESS</h2>
      
      </div>
      <div class="roadmap__wrapper">
        <div class="row gy-4 gy-md-0 gx-5">
          <div class="col-md-6 offset-md-6">
            <div class="roadmap__item ms-md-4 aos-init aos-animate" data-aos="fade-left" data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3   class="xx">Check The Rates</h3>
                    <span>1</span>
                  </div>
               
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-6">
            <div class="roadmap__item roadmap__item--style2 ms-auto me-md-4 aos-init aos-animate" data-aos="fade-right"
              data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3 class="xx">Contact Our Customer Care</h3>
                    <span>2</span>
                  </div>
                 
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-6 offset-md-6">
            <div class="roadmap__item ms-md-4 aos-init" data-aos="fade-left" data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3 class="xx">Confirm Your Amount</h3>
                    <span>3</span>
                  </div>
          
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="roadmap__item roadmap__item--style2 ms-auto me-md-4 aos-init" data-aos="fade-right"
              data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3 class="xx">Confirm Your Destination/Medium To Receive</h3>
                    <span>4</span>
                  </div>
               
                </div>
              </div>

            </div>
          </div>
          <div class="col-md-6 offset-md-6">
            <div class="roadmap__item ms-md-4 aos-init" data-aos="fade-left" data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3 class="xx">Make Your Payment</h3>
                    <span>5</span>
                  </div>
                 
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="roadmap__item roadmap__item--style2 ms-auto me-md-4 aos-init" data-aos="fade-right"
              data-aos-duration="800">
              <div class="roadmap__item-inner">
                <div class="roadmap__item-content">
                  <div class="roadmap__item-header">
                    <h3 class="xx">Get Your Confirmation Token</h3>
                    <span>6</span>
                  </div>
       
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="roadmap__shape">
      <span class="roadmap__shape-item roadmap__shape-item--1"> <span></span> </span>
      <span class="roadmap__shape-item roadmap__shape-item--2"> <img src="assets/images/icon/1.png" alt="shape-icon">
      </span>
    </div>
  </section>
  <!-- ========== Roadmap Section Ends Here========== -->



  <!-- ===============>> Pricing section start here <<================= -->









 




  <!-- ===============>> cta section start here <<================= -->
  <section class="cta padding-top padding-bottom  bg-color">
    <div class="container">
      <div class="cta__wrapper">
        <div class="cta__newsletter justify-content-center">
          <div class="cta__newsletter-inner" data-aos="fade-up" data-aos-duration="1000">
            <div class="cta__thumb">
              <img src="assets/images/cta/3.png" alt="cta-thumb">
            </div>
            <div class="cta__subscribe">
              <h2 class="xx"> <span>Subscribe</span> our news</h2> 
              <p class="xx">Hey! Are you tired of missing out on our updates? Subscribe to our news now and stay in the loop!</p>
              <form class="cta-form cta-form--style2 form-subscribe" action="#">
                <div class="cta-form__inner d-sm-flex align-items-center">
                  <input type="email" class="form-control form-control--style2 mb-3 mb-sm-0"
                    placeholder="Email Address">
                  <button class="trk-btn  trk-btn--large trk-btn--secondary2 xx" type="submit">Submit</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="cta__shape">
          <span class="cta__shape-item cta__shape-item--1"><img src="assets/images/cta/2.png" alt="shape icon"></span>
          <span class="cta__shape-item cta__shape-item--2"><img src="assets/images/cta/4.png" alt="shape icon"></span>
          <span class="cta__shape-item cta__shape-item--3"><img src="assets/images/cta/5.png" alt="shape icon"></span>
        </div>
      </div>
    </div>
  </section>
  <!-- ===============>> cta section start here <<================= -->





  <footer class="footer ">
    <div class="container">
      <div class="footer__wrapper">
        <div class="footer__top footer__top--style1">
          <div class="row gy-5 gx-4">
            <div class="col-md-6">
              <div class="footer__about">
                <a href="index.php" class="footer__about-logo"><img src="assets/images/logo/logo-dark.png"
                    alt="Logo" width="100%"></a>
              <p class="xx">Welcome to Second channel, where expert fund management meets personalized service. Our dedicated team is committed to efficiently and securely managing our clients' funds, ensuring peace of mind and optimal financial outcomes.</p>
              </div>
            </div>
            
            
            
          </div>
        </div>
        <div class="footer__bottom">
          <div class="">
            <div class="">
              <p style="text-align:center" class="xx">© 2024 All Rights Reserved By Second Channel</p>
            </div>
            <div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer__shape">
      <span class="footer__shape-item footer__shape-item--1"><img src="assets/images/footer/1.png"
          alt="shape icon"></span>
      <span class="footer__shape-item footer__shape-item--2"> <span></span> </span>
    </div>

    <div class="whatsapp_float">
        <a href="https://wa.me/971567953214" target="_blank"> <img src="assets/images/whatsapp.png" width="70%"></a>
    
    </div>
  </footer>


  <!-- ===============>> scrollToTop start here <<================= -->
  <!-- <a href="#" class="scrollToTop scrollToTop--style1"><i class="fa-solid fa-arrow-up-from-bracket"></i></a> -->
  <!-- ===============>> scrollToTop ending here <<================= -->


  <!-- vendor plugins -->

  <script src="assets/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/all.min.js"></script>
  <script src="assets/js/swiper-bundle.min.js"></script>
  <script src="assets/js/aos.js"></script>
  <script src="assets/js/fslightbox.js"></script>
  <script src="assets/js/purecounter_vanilla.js"></script>



  <script src="assets/js/custom.js"></script>

  <script>
        // Function to update the date and time every second
        function updateDateTime() {
            var currentDate = new Date();
            var dateTimeString = currentDate.toLocaleString(); // Convert date to string in local time format
            document.getElementById('datetime').innerText = "Date and Time: " + dateTimeString;
        }

        // Update the date and time initially
        updateDateTime();

        // Update the date and time every second
        setInterval(updateDateTime, 1000);
</script>

</body>


<!-- index.php  18:07:19 GMT -->
</html>